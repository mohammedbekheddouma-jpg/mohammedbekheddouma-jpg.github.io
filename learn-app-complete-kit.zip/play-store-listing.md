# Google Play Listing: تعلّم البرمجة

## App name (max 30)
تعلّم البرمجة

## Short description (max 80)
خريطة عملية لتعلّم هندسة البرمجيات: ويب، موبايل، ديسكتوب، DevOps وبيانات.

## Full description (max 4000)
تعلّم البرمجة تطبيق عربي واحد يضع أمامك المسار كاملاً لهندسة البرمجيات، بلا حشو ولا تشتيت.

ماذا تجد فيه؟

خريطة من أحد عشر قسماً، مرتّبة كما يجب أن تتعلّمها:
1. الأساسيات المشتركة: علوم الحاسوب، أساسيات البرمجة، الخوارزميات وهياكل البيانات، البرمجة الكائنية، Git وGitHub، لينكس، الشبكات، قواعد البيانات، مبادئ هندسة البرمجيات.
2. تطوير الواجهة الأمامية: من HTML5 وCSS3 إلى React وNext.js والاختبار والأداء وإتاحة الوصول.
3. تطوير الواجهة الخلفية: اللغات، الأطر مثل ASP.NET Core، قواعد البيانات، المصادقة، التخزين المؤقت، المعمارية النظيفة والأمان.
4. تطوير الويب الكامل: الطريق من أول عنصر HTML إلى النشر وتحسين محركات البحث.
5. تطبيقات الهاتف: مسارات Kotlin وSwift وFlutter وReact Native حتى النشر في المتاجر.
6. برامج سطح المكتب: WPF وWinUI وQt وElectron، مع قواعد البيانات والتغليف.
7. DevOps: لينكس، Docker، CI/CD، السحابة، Kubernetes، Terraform والمراقبة.
8. علوم البيانات: الرياضيات، Python، Pandas، الإحصاء، تعلم الآلة والتعلم العميق والنشر.
9. مقارنة التخصصات لتختار بوعي.
10. الخريطة الشاملة لتربط المجالات ببعضها.
11. ترتيب مقترح للتعلم خطوة بخطوة.

مع كل مسار: مشاريع تطبيقية حقيقية تبنى بعد كل مرحلة، ومصادر مجانية موثوقة.

تتبّع تقدّمك:
علّم على كل بند تنجزه، وشاهد شريط تقدّم لكل قسم ونسبة كلية. تقدّمك محفوظ في جهازك، ويعمل التطبيق بلا إنترنت بعد أول فتح.

لمن هذا التطبيق؟
- الطلبة في هندسة الإعلام الآلي وعلوم الحاسوب.
- من ينتقل إلى البرمجة من تخصص آخر.
- المبتدئ الذي لا يعرف من أين يبدأ.
- من يريد خريطة واضحة بدل عشرات الفيديوهات المتفرقة.

إعداد: محمد إبراهيم بخدومة عبدي، مهندس برمجيات من الجزائر.
الموقع: https://mohammedbekheddouma-jpg.github.io/

## Category
Education

## Tags
برمجة، تعلم، هندسة برمجيات، تطوير ويب، باك اند، بيانات

## Contact email
moh.ib.bekh@gmail.com

## Content rating
الجميع (لا محتوى حساس، لا إعلانات، لا مشتريات داخل التطبيق)

## Data safety (Play console answers)
- Does your app collect or share user data? No
- Data collected: none. Progress is stored locally on the device only.
- No ads, no analytics SDK, no third-party trackers.

## Assets included in this folder
- feature-graphic-1024x500.png  (Play feature graphic)
- shot-1-home.png ... shot-5-order.png (phone screenshots, 960x1708, ratio 1:1.78)
- icon-512.png (in the site repo: https://mohammedbekheddouma-jpg.github.io/learn/icon-512.png)

## Publishing route (PWA to Play, no coding)
1. Open https://www.pwabuilder.com
2. Paste https://mohammedbekheddouma-jpg.github.io/learn/ and press Start
3. Choose Package for stores, then Android
4. Package ID: com.mohammedbekheddouma.learnprogramming
5. App name: تعلّم البرمجة
6. Keep "Signing key: create new" and download the zip, which contains the .aab and assetlinks.json
7. Create a Play Console account (one time 25 USD, identity verification), then create the app and upload the .aab
8. Fill the listing with the texts above, upload the graphics, complete content rating and data safety
9. Send the app for review, usually a few days

## Ads and money (honest expectation)
- AdMob needs a live Play app first, then an ads account.
- Arabic education niche pays low rates per thousand views, so ads alone rarely cover more than a coffee a month at small scale.
- Real revenue comes from: paid course, paid PDF workbook, group teaching, or company sponsorship.
